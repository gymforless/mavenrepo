package @artifact.package@;

import com.google.gwt.event.shared.EventHandler;

public interface @artifact.name@Handler extends EventHandler {
    void onEvent(@artifact.name@Event event);
}
