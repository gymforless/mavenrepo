package @artifact.package@;

import com.google.gwt.core.client.EntryPoint;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class @artifact.name@ implements EntryPoint {
    /**
     * This is the entry point method.
     */
    public void onModuleLoad() {
    }
}
