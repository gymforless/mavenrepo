@package.line@import @action.package@.@action.name@Action
import @action.package@.@action.name@Response

class @action.name@ActionHandler {
    @action.name@Response execute(@action.name@Action action) {
        return null
    }
}
