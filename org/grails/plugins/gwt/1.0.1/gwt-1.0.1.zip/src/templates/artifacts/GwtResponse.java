package @artifact.package@;

import grails.plugins.gwt.shared.Response;

public class @artifact.name@Response implements Response {
    private static final long serialVersionUID = 1L;

    public @artifact.name@Response() {
    }
}
