package @artifact.package@;

import grails.plugins.gwt.shared.Action;

public class @artifact.name@Action implements Action<@artifact.name@Response> {
    private static final long serialVersionUID = 1L;

    public @artifact.name@Action() {
    }
}
