package org.grails.plugins.elasticsearch.unwrap

/**
 * @author Noam Y. Tenne.
 */
public interface DomainClassUnWrapper {

    def unWrap(object)
}