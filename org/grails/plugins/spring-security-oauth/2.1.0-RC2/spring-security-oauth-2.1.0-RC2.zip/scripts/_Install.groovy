println '''
*********************************************************************
* You've installed the Spring Security OAuth plugin.                *
*                                                                   *
* Next run the "grails s2-init-oauth" script to configure plugin.   *
*                                                                   *
*********************************************************************
'''