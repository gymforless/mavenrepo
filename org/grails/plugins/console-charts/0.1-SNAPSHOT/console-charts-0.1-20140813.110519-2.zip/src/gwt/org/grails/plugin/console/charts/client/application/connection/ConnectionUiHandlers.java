package org.grails.plugin.console.charts.client.application.connection;

import com.gwtplatform.mvp.client.UiHandlers;

/**
 * @author <a href='mailto:donbeave@gmail.com'>Alexey Zhokhov</a>
 */
public interface ConnectionUiHandlers extends UiHandlers {

    void onSendClicked();

}
