package grails.plugins.sitemapper.artefact;

import org.codehaus.groovy.grails.commons.GrailsClass;

public interface SitemapperClass extends GrailsClass {
  // Nothing to see here, move along..
}
