package grails.plugins.sitemapper;

/**
 * @author Kim A. Betti
 */
public interface SitemapServerUrlResolver {

  String getServerUrl();

}