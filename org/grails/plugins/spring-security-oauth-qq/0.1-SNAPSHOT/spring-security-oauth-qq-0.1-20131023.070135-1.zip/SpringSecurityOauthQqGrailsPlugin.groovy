class SpringSecurityOauthQqGrailsPlugin {
  def version = '0.1-SNAPSHOT'
  def grailsVersion = '2.0 > *'
  def dependsOn = [springSecurityOauth: '2.0.1.1 > *']
  def pluginExcludes = [
      'grails-app/views/error.gsp'
  ]

  def title = 'QQ support for Spring Security OAuth plugin'
  def author = 'Alexey Zhokhov'
  def authorEmail = 'donbeave@gmail.com'
  def description = '''Add QQ [Spring Security OAuth plugin|http://grails.org/plugin/spring-security-oauth].'''

  def documentation = 'http://grails.org/plugin/spring-security-oauth-qq'

  def license = 'APACHE'
  def developers = [[name: 'Alexey Zhokhov', email: 'donbeave@gmail.com']]
  def scm = [url: 'https://github.com/donbeave/grails-spring-security-oauth-qq/']
}
