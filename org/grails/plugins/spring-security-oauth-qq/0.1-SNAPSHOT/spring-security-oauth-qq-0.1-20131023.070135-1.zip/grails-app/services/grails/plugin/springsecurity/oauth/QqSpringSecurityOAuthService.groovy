package grails.plugin.springsecurity.oauth

import org.springframework.social.qq.api.impl.QQTemplate

class QqSpringSecurityOAuthService {

  def oauthService

  def createAuthToken(accessToken) {
    def config = oauthService.services.get('qq').service.config

    String appid = config.apiKey;
    String appkey = config.apiSecret;

    String pf = 'qzone';

    QQTemplate qqTemplate = new QQTemplate(appid, appkey, accessToken.token, pf)

    println qqTemplate.userOperations().userProfile.nickName
  }

}
