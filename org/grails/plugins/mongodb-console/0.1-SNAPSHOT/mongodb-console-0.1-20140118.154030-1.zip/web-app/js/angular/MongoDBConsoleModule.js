var MongoDBConsoleModule = angular.module('MongoDBConsoleModule', ['GrailsModule', 'ui']);
