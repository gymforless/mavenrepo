function ServerCtrl($scope, $routeParams, mongodb, mongoContextHolder, $http, grails, $location) {

}