/* Copyright 2009-2012 SpringSource.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Creates ACL domain classes in the project directory. The package and names cannot be
 * specified since plugin classes depend on them. But they should be in the project's
 * grails-app/domain folder to allow customization such as Hibernate 2nd-level caching.
 *
 * @author <a href='mailto:burt@burtbeckwith.com'>Burt Beckwith</a>
 */

includeTargets << new File("$springSecurityCorePluginDir/scripts/_S2Common.groovy")

USAGE = """
Usage: grails s2-create-acl-domains <domain-class-package> <acl-class-name> <acl-entry-class-name> <acl-object-identity-class-name> <acl-sid-class-name>

Creates ACL Domain classes in the specified package

Example: grails s2-create-acl-domains com.yourapp AclClass AclEntry AclObjectIdentity AclSid
"""

includeTargets << grailsScript('_GrailsBootstrap')

packageName = ''
aclClassName = ''
aclEntryClassName = ''
aclObjectIdentityClassName = ''
aclSidClassName = ''
templateDir = "$springSecurityAclPluginDir/src/templates"

target(s2CreateAclDomains: 'Creates ACL Domain classes for Spring Security ACL plugin') {
  depends(checkVersion, configureProxy, packageApp, classpath)

  if (!configure()) {
    return 1
  }
  createDomains()
  updateConfig()

  printMessage """
*******************************************************
* Created domain classes.                             *
* Your grails-app/conf/Config.groovy has been updated *
* with the class names of the configured domain       *
* classes; please verify that the values are correct. *
*******************************************************
"""
}

private boolean configure() {
  def argValues = parseArgs()
  if (!argValues) {
    return false
  }

  (packageName, aclClassName, aclEntryClassName, aclObjectIdentityClassName, aclSidClassName) = argValues

  templateAttributes = [packageName: packageName,
      aclClassName: aclClassName,
      aclEntryClassName: aclEntryClassName,
      aclObjectIdentityClassName: aclObjectIdentityClassName,
      aclSidClassName: aclSidClassName]

  true
}

private void createDomains() {
  String dir = packageToDir(packageName)

  generateFile "$templateDir/AclClass.groovy.template", "$appDir/domain/${dir}${aclClassName}.groovy"
  generateFile "$templateDir/AclEntry.groovy.template", "$appDir/domain/${dir}${aclEntryClassName}.groovy"
  generateFile "$templateDir/AclObjectIdentity.groovy.template", "$appDir/domain/${dir}${aclObjectIdentityClassName}.groovy"
  generateFile "$templateDir/AclSid.groovy.template", "$appDir/domain/${dir}${aclSidClassName}.groovy"
}

private void updateConfig() {
  def configFile = new File(appDir, 'conf/Config.groovy')

  if (configFile.exists()) {
    configFile.withWriterAppend {
      it.writeLine '\n// Added by the Spring Security ACL plugin:'
      it.writeLine "grails.plugins.springsecurity.acl.aclClass.className = '${packageName}.$aclClassName'"
      it.writeLine "grails.plugins.springsecurity.acl.aclEntry.className = '${packageName}.$aclEntryClassName'"
      it.writeLine "grails.plugins.springsecurity.acl.aclObjectIdentity.className = '${packageName}.$aclObjectIdentityClassName'"
      it.writeLine "grails.plugins.springsecurity.acl.aclSid.className = '${packageName}.$aclSidClassName'"
    }
  }
}

private parseArgs() {
  def args = argsMap.params

  if (5 == args.size()) {
    printMessage "Creating AclClass class ${args[1]} and AclEntry class ${args[2]} AclObjectIdentity class ${args[3]} AclSid class ${args[4]}  in package ${args[0]}"
    return args
  }

  errorMessage USAGE
  null
}

setDefaultTarget 's2CreateAclDomains'
